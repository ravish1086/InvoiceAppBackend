export const buyerSellerSchema =
   {
     "customerName": {
    "type": "String"
  },
  "customerContact": {
    "type": "Number"
  },
  "customerAddress": {
    "type": "String"
  },
  "customerCity": {
    "type": "String"
  },
  "customerState": {
    "type": "String"
  },
  "customerCountry": {
    "type": "String"
  },
  "isActive":{
    "type":"Number"
  }
}